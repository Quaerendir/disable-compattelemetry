# Changelog

All notable changes to this project will be documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] - 2026-04-05

### Added
- Initial release
- Task Scheduler hardening (4 tasks in `Application Experience`)
- `DiagTrack` and `dmwappushservice` service disabling
- Registry policy keys: `AllowTelemetry`, `DisableEngine`, `AITEnable`, `DisableInventory`, `CEIPEnable`
- Windows Error Reporting policy disable
- Optional `-NuclearAcl` switch for NTFS ACL deny-execute on binary
